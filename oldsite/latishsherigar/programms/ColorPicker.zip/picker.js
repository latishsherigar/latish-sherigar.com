
var init_text = "000000";
var init_back = "FFFFFF";
var init_link = "0000FF";
var init_vlink = "880088";
var init_hover = "0099FF";
var init_alink = "FF0000";


var text_r = init_text.substring(0,2);
var text_g = init_text.substring(2,4);
var text_b = init_text.substring(4,6);
var text_rgb = "" + text_r + text_g + text_b;

var back_r = init_back.substring(0,2);
var back_g = init_back.substring(2,4);
var back_b = init_back.substring(4,6);
var back_rgb = "" + back_r + back_g + back_b;

var link_r = init_link.substring(0,2);
var link_g = init_link.substring(2,4);
var link_b = init_link.substring(4,6);
var link_rgb = "" + link_r + link_g + link_b;

var vlink_r = init_vlink.substring(0,2);
var vlink_g = init_vlink.substring(2,4);
var vlink_b = init_vlink.substring(4,6);
var vlink_rgb = "" + vlink_r + vlink_g + vlink_b;

var hover_r = init_hover.substring(0,2);
var hover_g = init_hover.substring(2,4);
var hover_b = init_hover.substring(4,6);
var hover_rgb = "" + hover_r + hover_g + hover_b;

var alink_r = init_alink.substring(0,2);
var alink_g = init_alink.substring(2,4);
var alink_b = init_alink.substring(4,6);
var alink_rgb = "" + alink_r + alink_g + alink_b;

var link_underline = "";
var font_size = "";
var font_family = "";
var font_weight = "";
var font_style = "";

var hexcode_array = new Array('00','11','22','33','44','55','66','77','88','99','AA','BB','CC','DD','EE','FF');






function colorsAll(RGB)
{
   var RR = RGB.substring(0,2);
   var GG = RGB.substring(2,4);
   var BB = RGB.substring(4,6);

   //text
   if(window.document.pickerform.chooser[0].checked == true)
   {
      text_r = RR; text_g = GG; text_b = BB;
      text_rgb = "" + text_r + text_g + text_b;
      window.document.pickerform.colorbox_text.value = text_rgb;
      reColorAndGray(text_r,text_g,text_b);
      window.document.getElementById("heading").style.color = "#" + text_rgb;
      window.document.getElementById("text").style.color = "#" + text_rgb;
      window.document.getElementById("stylecode").style.color = "#" + text_rgb;
   }

   //back
   else if(window.document.pickerform.chooser[1].checked == true)
   {
      back_r = RR; back_g = GG; back_b = BB;
      back_rgb = "" + back_r + back_g + back_b;
      window.document.pickerform.colorbox_back.value = back_rgb;
      reColorAndGray(back_r,back_g,back_b);
      window.document.getElementById("rightcell").style.backgroundColor = "#" + back_rgb;
   }

   //link
   else if(window.document.pickerform.chooser[2].checked == true)
   {
      link_r = RR; link_g = GG; link_b = BB;
      link_rgb = "" + link_r + link_g + link_b;
      window.document.pickerform.colorbox_link.value = link_rgb;
      reColorAndGray(link_r,link_g,link_b);
      window.document.getElementById("link").style.color = "#" + link_rgb;
      window.document.getElementById("link2").style.color = "#" + link_rgb;
   }

   //vlink
   else if(window.document.pickerform.chooser[3].checked == true)
   {
      vlink_r = RR; vlink_g = GG; vlink_b = BB;
      vlink_rgb = "" + vlink_r + vlink_g + vlink_b;
      window.document.pickerform.colorbox_vlink.value = vlink_rgb;
      reColorAndGray(vlink_r,vlink_g,vlink_b);
      window.document.getElementById("vlink").style.color = "#" + vlink_rgb;
   }

   //hover
   else if(window.document.pickerform.chooser[4].checked == true)
   {
      hover_r = RR; hover_g = GG; hover_b = BB;
      hover_rgb = "" + hover_r + hover_g + hover_b;
      window.document.pickerform.colorbox_hover.value = hover_rgb;
      reColorAndGray(hover_r,hover_g,hover_b);
      window.document.getElementById("hover").style.color = "#" + hover_rgb;
   }

   //alink
   else if(window.document.pickerform.chooser[5].checked == true)
   {
      alink_r = RR; alink_g = GG; alink_b = BB;
      alink_rgb = "" + alink_r + alink_g + alink_b;
      window.document.pickerform.colorbox_alink.value = alink_rgb;
      reColorAndGray(alink_r,alink_g,alink_b);
      window.document.getElementById("alink").style.color = "#" + alink_rgb;
   }

   doBGImage();
   updateCode();
}


function colorsOne(RGorB,XX)
{
   //text
   if(window.document.pickerform.chooser[0].checked == true)
   {
      if(RGorB == "R") { text_r = XX; }
      else if(RGorB == "G") { text_g = XX; }
      else if(RGorB == "B") { text_b = XX; }
      text_rgb = "" + text_r + text_g + text_b;
      window.document.pickerform.colorbox_text.value = text_rgb;
      reColorAndGray(text_r,text_g,text_b);
      window.document.getElementById("heading").style.color = "#" + text_rgb;
      window.document.getElementById("text").style.color = "#" + text_rgb;
      window.document.getElementById("stylecode").style.color = "#" + text_rgb;
   }

   //back
   else if(window.document.pickerform.chooser[1].checked == true)
   {
      if(RGorB == "R") { back_r = XX; }
      else if(RGorB == "G") { back_g = XX; }
      else if(RGorB == "B") { back_b = XX; }
      back_rgb = "" + back_r + back_g + back_b;
      window.document.pickerform.colorbox_back.value = back_rgb;
      reColorAndGray(back_r,back_g,back_b);
      window.document.getElementById("rightcell").style.backgroundColor = "#" + back_rgb;
   }

   //link
   else if(window.document.pickerform.chooser[2].checked == true)
   {
      if(RGorB == "R") { link_r = XX; }
      else if(RGorB == "G") { link_g = XX; }
      else if(RGorB == "B") { link_b = XX; }
      link_rgb = "" + link_r + link_g + link_b;
      window.document.pickerform.colorbox_link.value = link_rgb;
      reColorAndGray(link_r,link_g,link_b);
      window.document.getElementById("link").style.color = "#" + link_rgb;
      window.document.getElementById("link2").style.color = "#" + link_rgb;
   }

   //vlink
   else if(window.document.pickerform.chooser[3].checked == true)
   {
      if(RGorB == "R") { vlink_r = XX; }
      else if(RGorB == "G") { vlink_g = XX; }
      else if(RGorB == "B") { vlink_b = XX; }
      vlink_rgb = "" + vlink_r + vlink_g + vlink_b;
      window.document.pickerform.colorbox_vlink.value = vlink_rgb;
      reColorAndGray(vlink_r,vlink_g,vlink_b);
      window.document.getElementById("vlink").style.color = "#" + vlink_rgb;
   }

   //hover
   else if(window.document.pickerform.chooser[4].checked == true)
   {
      if(RGorB == "R") { hover_r = XX; }
      else if(RGorB == "G") { hover_g = XX; }
      else if(RGorB == "B") { hover_b = XX; }
      hover_rgb = "" + hover_r + hover_g + hover_b;
      window.document.pickerform.colorbox_hover.value = hover_rgb;
      reColorAndGray(hover_r,hover_g,hover_b);
      window.document.getElementById("hover").style.color = "#" + hover_rgb;
   }

   //alink
   else if(window.document.pickerform.chooser[5].checked == true)
   {
      if(RGorB == "R") { alink_r = XX; }
      else if(RGorB == "G") { alink_g = XX; }
      else if(RGorB == "B") { alink_b = XX; }
      alink_rgb = "" + alink_r + alink_g + alink_b;
      window.document.pickerform.colorbox_alink.value = alink_rgb;
      reColorAndGray(alink_r,alink_g,alink_b);
      window.document.getElementById("alink").style.color = "#" + alink_rgb;
   }

   doBGImage();
   updateCode();
}



function reColorAndGray(RR,GG,BB)
{
   //recolor codes
   for(var i = 0; i < 16; i++) { window.document.getElementById("R" + hexcode_array[i]).style.backgroundColor = "#ffdddd"; }
   for(var i = 0; i < 16; i++) { window.document.getElementById("G" + hexcode_array[i]).style.backgroundColor = "#ddffdd"; }
   for(var i = 0; i < 16; i++) { window.document.getElementById("B" + hexcode_array[i]).style.backgroundColor = "#ddddff"; }

   //gray out current
   window.document.getElementById("R" + RR).style.backgroundColor = "#bbbbbb";
   window.document.getElementById("G" + GG).style.backgroundColor = "#bbbbbb";
   window.document.getElementById("B" + BB).style.backgroundColor = "#bbbbbb";
}




function chooserMode(MODE)
{
   if(MODE == "text") { var RGB = text_rgb; }
   else if(MODE == "link") { var RGB = link_rgb; }
   else if(MODE == "vlink") { var RGB = vlink_rgb; }
   else if(MODE == "alink") { var RGB = alink_rgb; }
   else if(MODE == "back") { var RGB = back_rgb; }
   else if(MODE == "hover") { var RGB = hover_rgb; }


   var RR = RGB.substring(0,2);
   var GG = RGB.substring(2,4);
   var BB = RGB.substring(4,6);

   reColorAndGray(RR,GG,BB);

   doBGImage();
}



function updateCode()
{
   var URL = window.document.pickerform.bgimage.value;
   var bgcode_style = "";
   var bgcode_body = "";
   if(URL != "")
   {
      bgcode_style = "<br><nobr>&nbsp\;&nbsp\;&nbsp\;background-image:url(" + URL + ")\;</nobr>"
      bgcode_body = "<br>&nbsp\;background=\"" + URL + "\"";
   }

   var newcode = "";

   newcode += "<b><i>Your body/link style:</i></b>";
   newcode += "<br><small>(Use this if you are defining your colors via CSS)</small>";
   newcode += "<br>&nbsp\;";
   newcode += "<span style=\"font:normal 9pt courier new\" id=\"code_style\">";
   newcode += "<br>&lt\;style type=\"text/css\"&gt\;";
   newcode += "<br>&nbsp\;";
   newcode += "<br>body \{";

   newcode += bgcode_style;

   newcode += "<br>&nbsp\;&nbsp\;&nbsp\;background-color:#" + back_rgb + "\;";
   newcode += "<br>&nbsp\;&nbsp\;&nbsp\;color:#" + text_rgb + "\;";

   newcode += font_family;
   newcode += font_size;
   newcode += font_weight;
   newcode += font_style;

   newcode += "<br>\}";
   newcode += "<br>&nbsp\;";
   newcode += "<br>a:link \{ color:#" + link_rgb + "\;" + link_underline + " \}";
   newcode += "<br>a:vlink \{ color:#" + vlink_rgb + "\;" + link_underline + " \}";
   newcode += "<br>a:alink \{ color:#" + alink_rgb + "\;" + link_underline + " \}";
   newcode += "<br>a:hover \{ color:#" + hover_rgb + "\;" + link_underline + " \}";
   newcode += "<br>&nbsp\;";
   newcode += "<br>&lt\;/style&gt\;";
   newcode += "<br>&nbsp\;";
   newcode += "</span>";

   //newcode += "<br><input type=button value=\"Open test page\" onClick=\"openTestPageStyle()\" style=\"font:normal 11px verdana\;\">";

   newcode += "<hr>";
   newcode += "<b><i>Your body tag:</i></b>";
   newcode += "<br><small>(Use this if you are defining your colors via the body tag)</small>";
   newcode += "<br>&nbsp\;";
   newcode += "<span style=\"font:normal 9pt courier new\" id=\"code_body\">";
   newcode += "<br>&lt\;body";
   newcode += bgcode_body + "<br>&nbsp\;bgcolor=\"#" + back_rgb + "\"";
   newcode += "<br>&nbsp\;text=\"#" + text_rgb + "\"";
   newcode += "<br>&nbsp\;link=\"#" + link_rgb + "\"";
   newcode += "<br>&nbsp\;vlink=\"#" + vlink_rgb + "\"";
   newcode += "<br>&nbsp\;alink=\"#" + alink_rgb + "\"&gt\;";
   newcode += "<br>&nbsp\;";
   newcode += "</span>";

   //newcode += "<br><input type=button value=\"Open test page\" onClick=\"openTestPageBody()\" style=\"font:normal 11px verdana\;\">";



   window.document.getElementById("stylecode").innerHTML = newcode;

}



function liteLinkOn(MYLINK)
{
   window.document.getElementById(MYLINK).style.color = "#" + hover_rgb;
}
function liteLinkOff(MYLINK)
{
   if(MYLINK == "link2")
   {
      window.document.getElementById(MYLINK).style.color = "#" + link_rgb;
   }
   else
   {
      window.document.getElementById(MYLINK).style.color = "#" + eval(MYLINK + "_rgb");
   }
}





function fillColorBoxes()
{
   window.document.pickerform.colorbox_text.value = text_rgb;
   window.document.pickerform.colorbox_link.value = link_rgb;
   window.document.pickerform.colorbox_hover.value = hover_rgb;
   window.document.pickerform.colorbox_back.value = back_rgb;
   window.document.pickerform.colorbox_vlink.value = vlink_rgb;
   window.document.pickerform.colorbox_alink.value = alink_rgb;
}


function setInitialColors()
{
   window.document.getElementById("heading").style.color = "#" + text_rgb;
   window.document.getElementById("text").style.color = "#" + text_rgb;
   window.document.getElementById("stylecode").style.color = "#" + text_rgb;
   window.document.getElementById("rightcell").style.backgroundColor = "#" + back_rgb;
   window.document.getElementById("link").style.color = "#" + link_rgb;
   window.document.getElementById("link2").style.color = "#" + link_rgb;
   window.document.getElementById("vlink").style.color = "#" + vlink_rgb;
   window.document.getElementById("hover").style.color = "#" + hover_rgb;
   window.document.getElementById("alink").style.color = "#" + alink_rgb;
}



function doBold()
{
   if(window.document.pickerform.boldbox.checked == true)
   {
      window.document.getElementById("allspans").style.fontWeight = "bold";
      font_weight = "<br>&nbsp\;&nbsp\;&nbsp\;font-weight:bold\;";
   }
   else
   {
      window.document.getElementById("allspans").style.fontWeight = "normal";
      font_weight = "";
   }

   doBGImage();
}

function doItalic()
{
   if(window.document.pickerform.italicbox.checked == true)
   {
      window.document.getElementById("allspans").style.fontStyle = "italic";
      font_style = "<br>&nbsp\;&nbsp\;&nbsp\;font-style:italic\;";
   }
   else
   {
      window.document.getElementById("allspans").style.fontStyle = "normal";
      font_style = "";
   }

   doBGImage();
}



function doFontSize(PX)
{
   if(PX == "default")
   {
      window.document.getElementById("allspans").style.fontSize = "";
      font_size = "";
   }
   else
   {
      window.document.getElementById("allspans").style.fontSize = PX + "px";
      font_size = "<br>&nbsp\;&nbsp\;&nbsp\;font-size:" + PX + "px\;";
   }

   doBGImage();
}

function doFontFamily(FONT)
{
   if(FONT == "default")
   {
      FONT = "";
      font_family = "";
   }
   else
   {
      font_family = "<br>&nbsp\;&nbsp\;&nbsp\;font-family:" + FONT + "\;";
   }

   window.document.getElementById("allspans").style.fontFamily = FONT;

   doBGImage();
}


function doUnderlineLinks()
{
   if(window.document.pickerform.underlinelinksbox.checked == true)
   {
      link_underline = "";
      window.document.getElementById("link").style.textDecoration = "underline";
      window.document.getElementById("link2").style.textDecoration = "underline";
      window.document.getElementById("vlink").style.textDecoration = "underline";
      window.document.getElementById("alink").style.textDecoration = "underline";
      window.document.getElementById("hover").style.textDecoration = "underline";
   }
   else
   {
      link_underline = " text-decoration:none\;";
      window.document.getElementById("link").style.textDecoration = "none";
      window.document.getElementById("link").style.textDecoration = "none";
      window.document.getElementById("link2").style.textDecoration = "none";
      window.document.getElementById("vlink").style.textDecoration = "none";
      window.document.getElementById("alink").style.textDecoration = "none";
      window.document.getElementById("hover").style.textDecoration = "none";
   }

   doBGImage();
}


function doBGImage()
{
   var IMG = window.document.pickerform.bgimage.value;

   if(IMG)
   {
      window.document.getElementById("rightcell").style.backgroundImage = "url(" + IMG + ")";
      updateCode();
   }
   else
   {
      window.document.getElementById("rightcell").style.backgroundImage = "";
      updateCode();
   }
}



/* KILLED FOR NOW
function openTestPageStyle()
{
   var mycode = window.document.getElementById("code_style").innerText;

   testWin = window.open("testpage.html","");

   testWin.document.open();

   testWin.document.writeln("<html>");
   testWin.document.writeln("<head>");
   testWin.document.writeln("<title>ColorPicker test page</title>");
   testWin.document.write(mycode);
   testWin.document.writeln("\n</head>");
   testWin.document.writeln("<body>\n");

   testWin.document.writeln("<P>Now is the time for all good men to come to the aid of their country.");
   testWin.document.writeln("<P>And here is a <a href=\"http://www.neverbeenthere.com/\">link</a>.");
   testWin.document.writeln("<P>View the source of this page to see how everything goes together.\n");

   testWin.document.writeln("</body>");
   testWin.document.writeln("</html>");

   testWin.document.close();
}
*/

/* KILLED FOR NOW
function openTestPageBody()
{
   var mycode = window.document.getElementById("code_body").innerText;

   testWin = window.open("testpage.html","");

   testWin.document.open();

   testWin.document.writeln("<html>");
   testWin.document.writeln("<head>");
   testWin.document.writeln("<title>ColorPicker test page</title>");
   testWin.document.writeln("</head>");
   testWin.document.write(mycode);

   testWin.document.writeln("\n<P>Now is the time for all good men to come to the aid of their country.");
   testWin.document.writeln("<P>And here is a <a href=\"http://www.neverbeenthere.com/\">link</a>.");
   testWin.document.writeln("<P>View the source of this page to see how everything goes together.\n");

   testWin.document.writeln("</body>");
   testWin.document.writeln("</html>");

   testWin.document.close();
}
*/


function backHelp()
{
   alert("Enter the full URL of an image.\nSomething like: http://www.mydomain.com/myback.jpg\n\nYou can of course use a relative URL, but make sure that your web page can find the image.");
}






function startMeUp()
{
   fillColorBoxes();
   chooserMode('back');
   setInitialColors();
   updateCode();
   doFontSize("default");
}

