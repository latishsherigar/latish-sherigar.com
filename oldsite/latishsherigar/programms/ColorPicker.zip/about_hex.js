function decToHex()
{
   enteredDec = (window.document.convert.dec.value * 1);

   if((enteredDec * 1 != enteredDec)||(Math.floor(enteredDec) != enteredDec)||(enteredDec < 0)||(enteredDec == ""))
   {
      alert("Please enter a whole positive decimal number in the left box.");
   }
   else
   {
      converted = enteredDec.toString(16);
      converted = enteredDec.toString(16);
      converted = converted.toUpperCase()
      window.document.convert.hex.value = converted;
   }
}


function hexToDec()
{
   enteredHex = window.document.convert.hex.value;


   if(isValid(enteredHex,validhex))
   {
      converted = parseInt(enteredHex,16);
      window.document.convert.dec.value = converted;
   }
   else
   {
      alert("Please enter a valid hexidecimal number.\n\nA valid hexidecimal number would contain ONLY the characters...\n\n0123456789ABCDEF\n\nNo spaces, dashes or periods.");
   }

}


function isValid(string,allowed)
{
   for (var i=0; i< string.length; i++)
   {
      if (allowed.indexOf(string.charAt(i)) == -1)
      {
         return false;
      }
   }

   if(string == "")
   {
      return false;
   }
   else
   {
      return true;
   }
}
var validhex = '0123456789ABCDEFabcdef';


