=======================================================================
ColorPicker v3.1                                          by Joe Barta
http://www.pagetutor.com/                         jbarta@pagetutor.com
=======================================================================

THIS SOFTWARE IS FREEWARE AND IS FREELY DISTRIBUTABLE

DESCRIPTION: An easy to use web page color picker that generates
CCS or HTML code that can be pasted into your web page.

SHORT DESCRIPTION: An easy to use web page color picker
SCREEN CAPTURE: http://www.pagetutor.com/caps/colorpicker.gif
ICON (32x32): http://www.pagetutor.com/pticons/colorpicker.gif
DOWNLOAD LOCATION: http://www.pagetutor.com/freeware/ColorPicker.exe
ZIPPED DOWNLOAD: http://www.pagetutor.com/freeware/ColorPicker.zip
PAD FILE: http://www.pagetutor.com/pad/colorpicker.xml
HOMEPAGE: http://www.pagetutor.com/
VERSION: 3.1
RELEASE DATE: 12/14/2006
AUTHOR: Joe Barta - PageTutor.com
EMAIL: jbarta@pagetutor.com
DISTRIBUTION: This file is freely distributable.
LICENSE: Freeware

ABOUT HTA FILES: HTML Applications are nothing more than simple HTML
files with an .hta extension and a little extra (optional) coding.
They require Internet Explorer version 5 or greater and use Explorer
components in a self-contained application environment. They're nowhere
near as robust as conventional applications, but are perfectly suited
for distributing HTML widget type applications like this one.
